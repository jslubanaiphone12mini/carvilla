<div id="tnp-heading">
    <h2><?php echo esc_html($email->subject) ?> <?php echo $this->get_date_badge($email) ?></h2>
    <?php include __DIR__ . '/nav.php' ?>
</div>

