<?php

define('THEME_DIR', get_template_directory_uri());